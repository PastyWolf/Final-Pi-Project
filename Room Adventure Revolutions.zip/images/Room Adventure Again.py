###########################################################################################
# Name: Anna Wolf
# Date: 03/23/18
# Description: Room Adventure Revolutions
###########################################################################################

###########################################################################################
from Tkinter import *

# the blueprint for a room
class Room(object):
        # the constructor
        def __init__(self, name, image):
                # rooms have a name, an image (the name of a file),
                # exits (e.g., south), exit locations (e.g., to the south is room n),
                # items (e.g., table), item descriptions (for each item), and grabbables (things that can
                # be taken into inventory)
                self.name = name
                self.image = image
                self.exits ={}
                self.items = {}
                self.grabbables = []

        # getters and setters for the instance variables
        @property
        def name(self):
                return self._name

        @name.setter
        def name(self, value):
                self._name = value

        @property
        def image(self):
                return self._image

        @image.setter
        def image(self, value):
                self._image = value
                
        @property
        def exits(self):
                return self._exits

        @exits.setter
        def exits(self, value):
                self._exits = value

        @property
        def items(self):
                return self._items

        @items.setter
        def items(self, value):
                self._items = value

        @property
        def grabbables(self):
                return self._grabbables

        @grabbables.setter
        def grabbables(self, value):
                self._grabbables = value

        # adds an exit to the room
        # the exit is a string (e.g., north)
        # the room is an instance of a room
        def addExit(self, exit, room):
                # append the exit and room to the appropriate dictionary
                self._exits[exit] = room

        # adds an item to the room
        # the item is a string (e.g., table)
        # the desc is a string that describes the item (e.g., it is made of wood)
        def addItem(self, item, desc):
                # append the item and description to the appropriate dictionary
                self._items[item] = desc

        # adds a grabbable item to the room
        # the item is a string (e.g., key)
        def addGrabbable(self, item):
                # append the item to the list
                self._grabbables.append(item)

        # removes a grabbable item from the room
        # the item is a string (e.g., key)
        def delGrabbable(self, item):
                # remove the item from the list
                self._grabbables.remove(item)

        # returns a string description of the room
        def __str__(self):
                # first, the room name
                s = "You are in {}.\n".format(self.name)

                # next, the items in the room
                s += "You see: "
                for item in self.items.keys():
                        s += item + " "
                s += "\n"

                # next, the exits from the room
                s += "Exits: "
                for exit in self.exits.keys():
                        s += exit + " "

                return s

# The game class
# Inherits from the Frame class of Tkinter
class Game(Frame):
        # The constructor
        def __init__(self, parent):
                # Call the constructor in the superclass
                Frame.__init__(self, parent)

        # creates the rooms
        def createRooms(self):
                # create the rooms and give them meaningful names and an image
                r1 = Room("front yard", "OUTSIDE.gif")
                r2 = Room("front porch", "FRONTDOOR.gif")
                r3 = Room("living room", "LIVINGROOM.gif")
                r4 = Room("foyer", "STAIRCASE.gif")
                r5 = Room("master bedroom", "BEDROOM.gif")
                r6 = Room("hallway", "HALLWAY.gif")
                r7 = Room("spare bedroom", "SPARE BEDROOM.gif")
                r8 = Room("backyard", "BACKYARD.gif")
                r9 = Room("bathroom", "BATHROOM.gif")
                r10 = Room("computer room", "COMPUTERROOM.gif")
                r11 = Room("attic", "ATTIC.gif")
                r12 = Room("attic", "WINDOW.gif")

                # add exits to room 1
                r1.addExit("north", r2) 
                # add grabbables to room 1
                r1.addGrabbable("flowers")
                # add items to room 1
                r1.addItem("shrub", "In its wild growth you see a couple of matured flowers.")
                r1.addItem("front-door", "It is mostly glass. You can see right through it.")

                # add exits to room 2
                r2.addExit("south", r1)
                r2.addExit("north", r3)
                # add items to room 2
                r2.addItem("doorbell", "Ring-A-Ding-Ding. No one answers. Let's investigate.")
                r2.addItem("flower-pot", "Looks like our fellow neighbor can't take care of plants.")

                # add exits to room 3
                r3.addExit("south", r2)
                r3.addExit("west", r4)
                r3.addExit("east", r5)
                r3.addExit("north", r8)
                # add grabbables to room 3
                r3.addGrabbable("book")
                r3.addGrabbable("urn")
                r3.addGrabbable("binder")
                # add items to room 3
                r3.addItem("book", "50 Shades of Grey? I'll just put that back down.")
                r3.addItem("mirror", "You motion finger guns at yourself and slick back your eyebrows.")
                r3.addItem("table", "The glass table holds an urn as well as an empty binder.")

                # add exits to room 4
                r4.addExit("upstairs", r6)
                r4.addExit("east", r3)       
                # add items to room 4
                r4.addItem("lamp", "The lights reflections cause shadows to move across the walls.")

                # add exits to room 5
                r5.addExit("west", r3)
                r5.addExit("east", r9)
                # add items to room 5
                r5.addItem("bed", "Pristine just everything else in this showcase house. No signs of life to be seen.")
                r5.addItem("wardrobe", "It's completely empty. Why even own a wardrobe?")                
                # add grabbables to room 6
                r6.addGrabbable("statue")
                r6.addGrabbable("candle")
                # add items to room 6
                r6.addItem("table", "On its shelf rests a statue of some indistinct religious idol as well as a candle that's never been lit.")
                # add exits to room 6
                r6.addExit("downstairs", r4)
                r6.addExit("east", r7)
                r6.addExit("west", r10)
                r6.addExit("upstairs", r11)

                # add exits to room 7
                r7.addExit("west", r6)
                # add grabbables to room 7
                r7.addGrabbable("pillow")
                # add items to room 7
                r7.addItem("pillow", "Feather filled, might be good for a fight. But it still has a tag on it?")
                r7.addItem("photo", "Looks like one those fake photos that companies put in the picture frames as filler.")
                r7.addItem("blanket", "Folded perfectly. Only a single hair lies on it. The owner's?")

                # add exits to room 8          
                r8.addExit("south", r3)
                # add grabbables to room 8
                r8.addGrabbable("beach-ball")
                # add items to room 8
                r8.addItem("swimming-pool", "The water glistens from reflective light. A beach ball floats in the middle. There are no other signs of use.")

                # add exits to room 9
                r9.addExit("west", r5)
                # add grabbables to room 9
                r9.addGrabbable("soap")
                # add Items to room 9
                r9.addItem("soap", "A container from Bath and Body Works, it's never been popped open.")
                r9.addItem("tub", "You can see steam rising from the water. Who poured the water?")
                r9.addItem("rug", "You run your feet through the soft fabric. When you look down, they are stained a slight color of red.")

                r10.addExit("east", r6)
                r10.addGrabbable("mousepad")
                # add items to room 8
                r10.addItem("computer", "An apple computer with a windows background screen. Suspicious. You notice half a finger print on the otherwise spotless screen.")
                r10.addItem("mousepad", "Has a picture of Oprah on it.")
                r10.addItem("speaker", "It plays classical music.")

                # add exits to room 11
                r11.addExit("downstairs", r6)
                r11.addExit("east", r12)
                # add grabbables to room 11
                r11.addGrabbable("wood")
                # add items to room 11
                r11.addItem("fire-place", "It burns dimly and a stack of wood lies beside it. Who lights the fire?")
                r11.addItem("cobweb", "You see a spider feast on struggling bugs. Morbid.")

                # add exits to room 12          
                r12.addExit("west", r11)
                r12.addExit("downstairs", r6)
                r12.addExit("north", None)
                # add items to room 12
                r12.addItem("window", "You sense a presence behind you. You have an overwhelming feeling to walk towards the window.")
                
                # set room 1 as the current room at the beginning of the game
                Game.currentRoom = r1

                # Initialize the player's inventory
                Game.inventory = []


        # sets up the GUI
        def setupGUI(self):
                # organize the GUI
                self.pack(fill=BOTH, expand=1)

                # Setup the player input at the bottom of the GUI
                # The widget is a Tkinter Entry
                # Set its background to white and bind the return key
                # to the function process in the class
                # Push it to the bottom of the GUI and let it fill horizontally
                # Give it focus so the player doesn't have to click on it
                Game.player_input = Entry(self, bg="white")
                Game.player_input.bind("<Return>", self.process)
                Game.player_input.pack(side=BOTTOM, fill=X)
                Game.player_input.focus()

                # Setup the image to the left of the GUI
                # The widget is a Tkinter label
                # Dont let the image control the widget's size
                img = None
                Game.image = Label(self, width=WIDTH / 2, image=img)
                Game.image.image = img
                Game.image.pack(side=LEFT, fill=Y)
                Game.image.pack_propagate(False)

                # Setup the text to the right of the GUI
                # First, the frame in which the text will be places
                text_frame = Frame(self, width=WIDTH / 2)
                # The widget is a Tkinter Text
                # Disable it by default, don't let the widget control the frame size
                Game.text = Text(text_frame, bg="lightgrey", state=DISABLED)
                Game.text.pack(fill=Y, expand=1)
                text_frame.pack(side=RIGHT, fill=Y)
                text_frame.pack_propagate(False)


        # Set the current room image
        def setRoomImage(self):
                if (Game.currentRoom == None):
                        # if dead, set the skull image
                        Game.img = PhotoImage(file="skull.gif")
                else:
                        # Otherwise, grab the image for the current room
                        Game.img = PhotoImage(file=Game.currentRoom.image)
                # Display the image on the left side of the GUI
                Game.image.config(image=Game.img)
                Game.image.image = Game.img

        # Sets the status displayed on the right of the GUI
        def setStatus(self, status):
                # enable the text widget, clear it, set it, and disable it
                Game.text.config(state=NORMAL)
                Game.text.delete("1.0",END)
                if (Game.currentRoom == None):
                        # If dead, let the player know
                        Game.text.insert(END, "You are dead. The only thing you can do now is quit.\n")
                else:
                        # otherwise, display the appropiate status
                        Game.text.insert(END, str(Game.currentRoom) +\
                                "\nYou are carrying: " + str(Game.inventory) +\
                                "\n\n" + status)
                Game.text.config(state=DISABLED)

        # Play the game
        def play(self):
                # Add the rooms to the game
                self.createRooms()
                # configure the GUI
                self.setupGUI()
                # set the current room
                self.setRoomImage()
                # set the current status
                self.setStatus("")

        # Processes the player's input
        def process(self, event):
                # Grab the player's input from the input at the bottom of the GUI
                action = Game.player_input.get()
                # Set the user's input to lowercase to make it easier to compare the verb and noun to known values
                action = action.lower()
                # Set a default response
                response = "I don't understand. Try a verb noun. Valid verbs are go, look ,and take."

                # Exit the game if the player wants to leave
                if (action == "quit" or action == "exit" or action == "bye"\
                    or action == "sionara!"):
                    exit(0)

                # If the player is dead
                if (Game.currentRoom == None):
                        # Clear the player's input
                        Game.player_input.delete(0, END)
                        return

                # Split the user input into words and store the words in a list
                words = action.split()

                # The game only understands two word inputs
                if (len(words) == 2):
                        # isolate the verb and noun
                        verb = words[0]
                        noun = words[1]

                        # The word is go
                        if (verb == "go"):
                                # set a default response
                                response = "Invalid exit."

                                # Check for valid exits in the current room
                                if (noun in Game.currentRoom.exits):
                                        # If one is found, change the current
                                        # room to the one that is associated
                                        # with the specified exit
                                        Game.currentRoom =\
                                              Game.currentRoom.exits[noun]
                                        # Set the response (success)
                                        response = "Room changed."
                        # The verb is look
                        elif (verb == "look"):
                                # set a default response
                                response = "I don't see that item."

                                # Check for valid items in the current room
                                if (noun in Game.currentRoom.items):
                                        # if one if found, set the response to
                                        # the item's description
                                        response = Game.currentRoom.items[noun]
                        # The verb is take
                        elif (verb == "take"):
                                # Set a default response
                                response = "I don't see that item."

                                # Check for valid grabbable item in inventory
                                for grabbable in Game.currentRoom.grabbables:
                                        # a valid grabbable item is found
                                        if (noun == grabbable):
                                                # add the grabbable item to
                                                # player's inventory
                                                Game.inventory.append(grabbable)
                                                # Remove the grabbable item
                                                # from the room
                                                Game.currentRoom.delGrabbable(grabbable)
                                                # set the response (success)
                                                response = "Item grabbed."
                                                # no need to check any more items
                                                break
                # Display the response on the right side of the GUI
                # Display the room's image on the left of the GUI
                # clear the player's input
                self.setStatus(response)
                self.setRoomImage()
                Game.player_input.delete(0, END)
                                              
#############################################################################
# the default size of the GUI is 800x600
WIDTH = 800
HEIGHT = 600

# Create the window
window = Tk()
window.title("Room Adventure")

# Create the GUI as a Tkinter canvas inside the window
g = Game(window)
# Play the game
g.play()

# Wait for the window to close
window.mainloop()

#For changing the picture if an object if taken: if blank is in inventory, do this picture
